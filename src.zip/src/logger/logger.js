let welcome = function()
{
    console.log( 'Welcome to my application. I am Pratik and a part of FunctionUp uranium cohort.')
}


module.exports.welcomemessage = welcome
 