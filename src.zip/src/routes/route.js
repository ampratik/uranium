const express = require('express');
const loggerModule = require('../logger/logger')
const helperModule = require('../util/helper')
const formatterModule = require('../validator/formatter')
const lodashModule = require('lodash')
const router = express.Router();

router.get('/test-me', function (req, res) {
    loggerModule.welcomemessage()
    helperModule.printTodaysDate()
    helperModule.printCurrentMonth()
    helperModule.printBatchInformation()
    formatterModule.trimString()
    formatterModule.changeCaseToUpper()
    formatterModule.changeCaseToLower()
    res.send('My first ever api!')
});

router.get('/test-me2', function (req, res) {
    console.log('I am inside the second route handler')
    res.send('My second ever api!')
});


router.get('/test-me5', function (req, res) {
    res.send('My final ever api!')
});

router.get('/test-me3', function (req, res) {
    res.send('My first ever api!')
});

router.get('/test-me4', function (req, res) {
    res.send('My first ever api!')
});


// adding this comment for no reason

router.get('/hello', function (req, res) {
    // Problem a)
    let months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    let subArrays = lodashModule.chunk(months, 3)
    console.log('The result after splitting the months array is ', subArrays)
    
    // Problem b)
    
    let oddNumbers = [1,3,5,7,9,11,13,15,17,19]
    console.log('The last 9 odd numbers in the array are: ', lodashModule.tail(oddNumbers))
    
    // Problem c)
    let a = [12 ,32, 21, 14]
    let b = [2, 3, 4, 3]
    let c = [6, 1, 2, 10]
    let d = [1, 1, 7]
    let e = [1, 2, 8, 4, 5]
    
    console.log('Final array or unique numbers is : ', lodashModule.union(a, b, c, d, e))
    
    // Problem d)
    let arrayOfKeyValuePairs = [["horror","The Shining"],["drama","Titanic"],["thriller","Shutter Island"],["fantasy","Pans Labyrinth"]]
    console.log('The object created from arrays is :', lodashModule.fromPairs(arrayOfKeyValuePairs))
        res.send('My hello api!')
    });


    module.exports = router;